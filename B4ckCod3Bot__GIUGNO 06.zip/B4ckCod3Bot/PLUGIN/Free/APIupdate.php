<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Update Telegram Bot API';
function Update_Telegram_Bot_API_info()
{
    return 'Plugin che permette di ricevere tutti gli updates delle bot API';
}
$update = file_get_contents('php://input');
$update = json_decode($update, TRUE); //Serve per codificare gli updates che il bot riceve
$code = json_encode($update, JSON_PRETTY_PRINT); //serve per en-codificarli (leggibili) gli updated che il bot riceve
if ($update) sm($chatID, $code, $menu, 'HTML', false, false, false); //Manda un messaggio ad ogni update
