<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Gestore di gruppi';
function Gestore_di_gruppi_info()
{
    return 'Utilizzando questo plugin, avrete la possibilità di gestire i vostri gruppi, con il <code>Tag Alert</code> ed il sistema di <code>Warn</code> incluso!';
}
function ban($chatID, $userID)
{
    global $API;
    global $api;
    $args = array(
        'chat_id' => $chatID,
        'user_id' => $userID
    );
    $r    = post('post', $API . 'kickChatMember', $args);
}
function unban($chatID, $userID)
{
    global $API;
    global $api;
    $args = array(
        'chat_id' => $chatID,
        'user_id' => $userID
    );
    $r    = post('post', $API . 'unbanChatMember', $args);
}
function setWarn($chatID, $userID, $warn)
{
    global $db;
    $db->exec('UPDATE `' . $chatID . "` SET `warn` = '" . $warn . "' WHERE `chat_id` = " . $userID);
}
$replyID   = $update['message']['reply_to_message']['from']['id'];
$replyNome = $update['message']['reply_to_message']['from']['first_name'];
if ($chatID < 0) {
    $db->exec('CREATE TABLE IF NOT EXISTS `' . $chatID . '` (
  `chat_id` bigint(20) NOT NULL,
  `username` varchar(200) NOT NULL,
  `warn` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;');
    $db->exec('CREATE TABLE IF NOT EXISTS `' . $chatID . '_impostazioni` (
  `regole` varchar(1000) NOT NULL,
  `benvenuto` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;');
    $quy = $db->query('SELECT count(*) FROM `' . $chatID . '_impostazioni`');
    if ($quy->fetchColumn() == 0) {
        $db->exec('INSERT INTO `' . $chatID . "_impostazioni`(`regole`, `benvenuto`) VALUES ('', '')");
    }
    $quy = $db->query('SELECT count(*) FROM `' . $chatID . '` WHERE `chat_id` = ' . $userID);
    if ($quy->fetchColumn() == 0) {
        $db->exec('INSERT INTO `' . $chatID . "`(`chat_id`, `username`, `warn`) VALUES (" . $userID . ", '" . $username . "', '0')");
    }
    if ($replyID) {
        $quy = $db->query('SELECT count(*) FROM `' . $chatID . '` WHERE `chat_id` = ' . $replyID);
        if ($quy->fetchColumn() == 0) {
            $db->exec('INSERT INTO `' . $chatID . "`(`chat_id`, `username`, `warn`) VALUES (" . $replyID . ", '" . $update['message']['reply_to_message']['from']['username'] . "', '0')");
        }
        $r = $db->query('SELECT * FROM `' . $chatID . '` WHERE `chat_id` = ' . $replyID);
        if ($r) {
            $l        = $r->fetch();
            $thewarnz = $l['warn'];
        }
    }
    $r = $db->query('SELECT * FROM `' . $chatID . '_impostazioni`');
    if ($r) {
        $impo = $r->fetch();
    }
}
$args   = array(
    'chat_id' => $chatID
);
$ris    = post('post', $API . 'getChatAdministrators', $args);
$admins = json_decode($ris, true);
foreach ($admins['result'] as $adminsa) {
    if ($adminsa['user']['id'] == $userID) {
        $isadmin = true;
    }
    if ($adminsa['user']['id'] == $userID and $adminsa['status'] == 'creator') {
        $isfounder = true;
    }
    if ($adminsa['user']['username'] == $userbot) {
        $botadmin = true;
    }
    if ($adminsa['user']['id'] == $replyID) {
        $loadmin = true;
    }
}
if ($msg == '/staff' and $chatID < 0 and $isadmin) {
    $shish = '⚜️ <b>STAFF</b> ⚜️';
    foreach ($admins['result'] as $ala) {
        if ($ala['status'] == 'creator') {
            $shish .= "\n" . strip_tags($ala['user']['first_name']) . ' - @' . $ala['user']['username'] . ' - 🔱 Fondatore del gruppo';
        } else {
            $shish .= "\n" . strip_tags($ala['user']['first_name']) . ' - @' . $ala['user']['username'];
        }
    }
    sm($chatID, $shish, false, 'HTML', false, 'default', false);
}
if ($msg == '/link' and $chatID < 0) {
    $link = exportChatInviteLink($chatID);
    if ($link['result']) {
        sm($chatID, '<b>Ecco il link del gruppo:</b>' . "\n" . $link['result']);
    }
    exit;
}
if ($msg == '/pin' and $chatID < 0 and $isadmin and isset($update['message']['reply_to_message']['message_id'])) {
    pinChatMessage($chatID, $update['message']['reply_to_message']['message_id']);
    sm($chatID, 'Messaggio fissato!');
    exit;
}
if ($msg == '/impostazioni' and $adminsa['user']['id'] == $userID and $chatID < 0) {
    sm($chatID, ' ℹ <i>Inviato in privato...</i>', false, 'HTML');
    $menug[] = array(
        array(
            'text' => '🕹 Benvenuto',
            'callback_data' => 'benvenuto ' . $chatID
        ),
        array(
            'text' => 'Regole 💾',
            'callback_data' => 'regole ' . $chatID
        )
    );
    sm($userID, '<b>Perfetto ' . $nome . '!</b>' . "\n" . 'Cosa vuoi modificare del gruppo?', $menug, 'HTML', false, false, true);
    exit;
}
if ($update['message']['new_chat_member'] and !empty($impo['benvenuto'])) {
    $primo_array = array(
        '[NOME]',
        '[COGNOME]',
        '[USERNAME]',
        '[ID]'
    );
    $secondo_array = array(
        $update['message']['new_chat_member']['first_name'],
        $update['message']['new_chat_member']['last_name'],
        $update['message']['new_chat_member']['username'],
        $id = $update['message']['new_chat_member']['id']
    );
    if (!isset($update['message']['new_chat_member']['username'])) {
        $secondo_array[2] = 'NESSUN USERNAME';
    }
    $text = str_replace($primo_array, $secondo_array, $impo['benvenuto']);
    sm($chatID, $text);
}
if ($msg == '/regole' and $chatID < 0 and !empty($impo['regole'])) {
    sm($chatID, $impo['regole']);
}
if ($update['message']['new_chat_title']) {
    $nuovo_nome = $update['message']['new_chat_title'];
    $text       = 'Nuovo nome gruppo: ' . $nuovo_nome;
    sm($chatID, $text);
}
if (strpos($msg, '/ban') === 0 and $isadmin and $botadmin and $chatID < 0) {
    $motivo = str_replace('/ban ', '', $msg);
    $motivo = str_replace('/ban', '', $motivo);
    $texto  = '<b>' . $replyNome . '</b> [' . $replyID . '] è stato bannato';
    if (!empty($motivo)) {
        $texto .= ' per <b>' . $motivo . '</b>!';
    } else {
        $texto .= '!';
    }
    if ($replyID and !$loadmin) {
        sm($chatID, $texto, false, 'HTML', false, $dadove);
        ban($chatID, $replyID);
    }
}
if (strpos($msg, '/kick') === 0 and $isadmin and $botadmin and $chatID < 0) {
    $motivo = str_replace('/kick ', '', $msg);
    $motivo = str_replace('/kick', '', $motivo);
    $texto  = '<b>' . $replyNome . '</b> [' . $replyID . '] è stato kickato';
    if (!empty($motivo)) {
        $texto .= ' per <b>' . $motivo . '</b>!';
    } else {
        $texto .= '!';
    }
    if ($replyID and !$loadmin) {
        sm($chatID, $texto, false, 'HTML', false, $dadove);
        ban($chatID, $replyID);
        unban($chatID, $replyID);
    }
}
if (strpos($msg, '/unban') === 0 and $isadmin and $botadmin and $chatID < 0) {
    $motivo = str_replace('/unban ', '', $msg);
    $motivo = str_replace('/unban', '', $motivo);
    $texto  = '<b>' . $replyNome . '</b> [' . $replyID . '] è stato sbannato';
    if (!empty($motivo)) {
        $texto .= ', questo perché <b>' . $motivo . '</b>!';
    } else {
        $texto .= '!';
    }
    if ($replyID and !$loadmin) {
        sm($chatID, $texto, false, 'HTML', false, $dadove);
        unban($chatID, $replyID);
    }
}
if (strpos($msg, '/warn') === 0 and $isadmin and $botadmin and $chatID < 0) {
    $motivo = str_replace('/warn ', '', $msg);
    $motivo = str_replace('/warn', '', $motivo);
    $texto  = '<b>' . $replyNome . '</b> [' . $replyID . '] ha <b>ricevuto</b> un avvertimento';
    if (!empty($motivo)) {
        $texto .= ' per <b>' . $motivo . '</b>!';
    } else {
        $texto .= '!';
    }
    $wewe = $thewarnz + 1;
    if ($wewe >= 3) {
        $lodevibannare = true;
    }
    if ($replyID and !$loadmin) {
        if ($lodevibannare) {
            setWarn($chatID, $replyID, 0);
            $texto .= "\n<b>Questo era l'" . 'ultimo avvertimento. Ora è stato bannato!</b>';
            ban($chatID, $replyID);
        } else {
            setWarn($chatID, $replyID, $wewe);
            $texto .= ' Ora hai <b>' . $wewe . '</b> avvertiment';
            if ($wewe == '1') {
                $texto .= 'o!';
            } else {
                $texto .= 'i!';
            }
        }
        $dadove = $update['message']['message_id'];
        sm($chatID, $texto, false, 'HTML', false, $dadove);
    }
}
if (strpos($msg, '/unwarn') === 0 and $isadmin and $botadmin and $chatID < 0) {
    $motivo = str_replace('/unwarn ', '', $msg);
    $motivo = str_replace('/unwarn', '', $motivo);
    $texto  = '<b>' . $replyNome . '</b> [' . $replyID . '] ha <b>eliminato</b> un avvertimento';
    if (!empty($motivo)) {
        $texto .= ' per <b>' . $motivo . '</b>!';
    } else {
        $texto .= '!';
    }
    $wewe = $thewarnz - 1;
    if ($replyID and !$loadmin) {
        setWarn($chatID, $replyID, $wewe);
        $texto .= ' Ora hai <b>' . $wewe . '</b> avvertiment';
        if ($wewe == '1') {
            $texto .= 'o!';
        } else {
            $texto .= 'i!';
        }
    }
    $dadove = $update['message']['message_id'];
    sm($chatID, $texto, false, "HTML", false, $dadove);
}
if ($chatID < 0) {
    $typechat    = $update['message']['chat']['type'];
    $tagPresenti = $update['message']['entities'];
    foreach ($tagPresenti as $currentTag) {
        if ($currentTag['type'] == 'mention') {
            $nomeTag2          = str_replace('@', '', trim(substr($msg, $currentTag['offset'], $currentTag['length'])));
            $querySelezioneTag = $db->query('SELECT * FROM `' . $table . "` WHERE `username` = '" . str_replace('@', '', trim(substr($msg, $currentTag['offset'], $currentTag['length']))) . "'", array(
                PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY
            ));
            $querySelezioneTag->execute();
            $riga   = $querySelezioneTag->fetch();
            $userid = $riga['chat_id'];
            $dadove = $update['message']['message_id'];
            if ($typechat == 'supergroup' and $usernamechat) {
                $menubeno[] = array(
                    array(
                        'text' => '🕹 Vai al messaggio',
                        'url' => 'http://telegram.me/' . $usernamechat . '/' . $dadove
                    )
                );
                $args2      = array(
                    'chat_id' => $chatID,
                    'user_id' => $userid
                );
                $lel        = post('post', $API . 'getChatMember', $args);
                $lolil      = json_decode($lel, true);
                if ($lolil['result']['status'] !== 'kicked' and $lolil['result']['status'] !== 'left') {
                    sm($userid, '<b>Sei stato menzionato da ' . $nome . ' [' . $userID . '] in</b> <i>' . $usernamechat . '!</i>' . "\n\n" . '<i>Premi qui, troverai poi un messaggio per trovare dove sei stato taggato!</i>', $menubeno, 'HTML', false, false, true);
                }
            } else {
                $menubengo[] = array(
                    array(
                        'text' => '🕹 Vai al messaggio',
                        'callback_data' => 'messaggio ' . $chatID . ':' . $dadove
                    )
                );
                $args2       = array(
                    'chat_id' => $chatID,
                    'user_id' => $userid
                );
                $lel         = post('post', $API . 'getChatMember', $args);
                $lolil       = json_decode($lel, true);
                if ($lolil['result']['status'] !== 'kicked' and $lolil['result']['status'] !== 'left') {
                    sm($userid, '<b>Sei stato menzionato da ' . $nome . ' [' . $userID . '] in</b> <i>' . $titolo . '!</i>' . "\n\n" . '<i>Premi qui, troverai poi un messaggio per trovare dove sei stato taggato!</i>', $menubengo, 'HTML', false, false, true);
                }
            }
        }
    }
}
if (strpos($cbdata, 'messaggio ') === 0 and $chatID > 0) {
    $cbdata   = str_replace('messaggio ', '', $cbdata);
    $i        = explode(':', $cbdata);
    $chattaID = $i[0];
    $mexoido  = $i[1];
    sm($chattaID, 'Ecco il messaggio ' . $nome . '! #tag' . $chatID, false, 'HTML', false, $mexoido);
    cb_reply($cbid, 'Okey!', false, $cbmid, ' ℹ Troverai il tuo messaggio usando queato tag:' . "\n\n" . '#tag' . $chatID);
    exit;
}
if (strpos($cbdata, 'menu ') === 0 and $chatID > 0) {
    $idgruppo = str_replace('menu ', '', $cbdata);
    $menug[]  = array(
        array(
            'text' => '🕹 Benvenuto',
            'callback_data' => 'benvenuto ' . $idgruppo
        ),
        array(
            'text' => 'Regole 💾',
            'callback_data' => 'regole ' . $idgruppo
        )
    );
    setPage($userID);
    cb_reply($cbid, 'Okey!', false, $cbmid, '<b>Perfetto ' . $nome . '!</b>' . "\n" . 'Cosa vuoi modificare del gruppo?', $menug, 'HTML');
    exit;
}
if (strpos($cbdata, 'benvenuto ') === 0 and $chatID > 0) {
    $idgruppo   = str_replace('benvenuto ', '', $cbdata);
    $annullal[] = array(
        array(
            'text' => '✖️ Annulla',
            "callback_data" => 'menu ' . $idgruppo
        )
    );
    setPage($userID, 'benvenuto ' . $idgruppo);
    cb_reply($cbid, 'Okey!', false, $cbmid, ' ℹ Invia ora il benvenuto!' . "\n\n" . '<code>P.S. Puoi usare tutti i tag ' . $config['formattazione_predefinita'] . ' e [NOME], [COGNOME], [USERNAME] ed [ID] per sostituirli con le informazioni necessarie.</code>', $annullal);
    exit;
}
if (strpos($cbdata, 'regole ') === 0 and $chatID > 0) {
    $idgruppo   = str_replace('regole ', '', $cbdata);
    $annullal[] = array(
        array(
            'text' => '✖️ Annulla',
            'callback_data' => 'menu ' . $idgruppo
        )
    );
    setPage($userID, 'regole ' . $idgruppo);
    cb_reply($cbid, 'Okey!', false, $cbmid, ' ℹ Invia ora le regole!', $annullal);
    exit;
}
if (strpos($u['page'], 'regole ') === 0 and $chatID > 0 and $msg) {
    setPage($userID);
    $idgruppo = str_replace('regole ', '', $u['page']);
    $r        = $db->prepare('UPDATE `' . $idgruppo . '_impostazioni` SET `regole` = :regole');
    $r->bindParam(':regole', $msg, PDO::PARAM_STR, 7);
    $r->execute();
    $menug[] = array(
        array(
            'text' => '🕹 Benvenuto',
            'callback_data' => 'benvenuto ' . $idgruppo
        ),
        array(
            'text' => 'Regole 💾',
            'callback_data' => 'regole ' . $idgruppo
        )
    );
    sm($userID, '<i>Regole modificate!</i>', $menug, 'HTML', false, false, true);
}
if (strpos($u['page'], 'benvenuto ') === 0 and $chatID > 0 and $msg) {
    setPage($userID);
    $idgruppo = str_replace('benvenuto ', '', $u['page']);
    $r        = $db->prepare('UPDATE `' . $idgruppo . '_impostazioni` SET `benvenuto` = :benvenuto');
    $r->bindParam(':benvenuto', $msg, PDO::PARAM_STR, 7);
    $r->execute();
    $menug[] = array(
        array(
            'text' => '🕹 Benvenuto',
            'callback_data' => 'benvenuto ' . $idgruppo
        ),
        array(
            'text' => 'Regole 💾',
            'callback_data' => 'regole ' . $idgruppo
        )
    );
    sm($userID, '<i>Benvenuto modificato!</i>', $menug, 'HTML', false, false, true);
}
