<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Downloader di file';
function Downloader_di_file_info()
{
    return 'Questo plugin permette lo scaricamento o l\'eliminazione di <code>file</code>, come documenti e foto, nel server attraverso il bot, con i comandi <code>/scaricafile</code> e <code>/eliminafile</code>';
}
if ($chatID > 0) {
    if ($msg == '/scaricafile' and $isadminbot) {
        setPage($userID, 'scaricafile');
        $men[] = array(
        array(
            'text' => '❌ Annulla',
            'callback_data' => 'resetpage_data'
        )
    );
        sm($userID, 'Perfetto <b>' . $nome . "</b>\n" . 'Invia il <b>file</b> che vuoi scaricare nel server!', $men, 'HTML', false, false, true);
        exit;
    }
    if ($cbdata == 'resetpage_data') {
        setPage($userID);
        cb_reply($cbid, '❌ Annullato', false, $cbmid, '❌ <b>Invio</b> del file <b>annullato</b>');
        exit;
    }
    if ($u['Page'] == 'scaricafile' and ($document or $video_note or $photo or $audio or $sticker or $voice) and $isadminbot == $userID) {
        setPage($userID);
        $tipi_di_file = array('document', 'video_note', 'photo', 'audio', 'sticker', 'voice');
        foreach ($update['message'] as $tipo_update => $valore_update) {
            if (in_array($tipo_update, $tipi_di_file)) {
                $tipo_file = $tipo_update;
                break;
            }
        }
        if ($tipo_file == 'document') {
            $nodoc = $update['message'][$tipo_file]['file_name'];
        } elseif ($tipo_file == 'photo') {
            $nodoc = time() . '.jpg';
        } elseif ($tipo_file == 'video_note') {
            $nodoc = time() . '.mp4';
        } elseif ($tipo_file == 'audio') {
            $nodoc = time() . '.mp3';
        } elseif ($tipo_file == 'sticker') {
            $nodoc = time() . '.webp';
        } elseif ($tipo_file == 'voice') {
            $nodoc = time() . '.ogg';
        }
        downloadFile($tipo_file, 'DATA/' . $nodoc);
        sm($userID, 'Il file <b>' . $nodoc . '</b> è stato scaricato e caricato con successo!');
        exit;
    }
    if ($msg == '/eliminafile' and $isadminbot == $userID and $chatID > 0) {
        $tastiera    = array();
        $r           = 0;
        $valori      = scandir('DATA');
        $file_intoccabili = array('_admin.json', '_comandi.json', '_config.json', '_data.json', '_plugin.json', '_risposte.json', '.', '..');
        $valori      = array_diff($valori, $file_intoccabili);
        if (!empty($valori)) {
            $n           = 1;
            $k           = 0;
            $limite_riga = 4;
            foreach ($valori as $valore) {
                if ($valore == '.' or $valore == '..') {
                    continue;
                }
                if ($n > $limite_riga) {
                    $n = 1;
                    $k++;
                }
        ;
                $tastiera[$k][] = array(
            'text' => $valore,
            'callback_data' => 'delfile|' . $valore
        );
                $n++;
            }
            sm($userID, 'Scegli il <b>file</b> da eliminare.', $tastiera, 'HTML', false, false, true);
        } else {
            sm($userID, 'La cartella dedicata ai file non ha <b>nessun file</b> da eliminare, se vuoi resettare i <b>json</b> necessari accedi da <b>FTP</b>');
        }
    }
    if (strpos($cbdata, 'delfile') === 0 and $isadminbot == $userID and $chatID > 0) {
        $i       = explode('|', $cbdata);
        $file    = $i[1];
        $menu1[] = array(
        array(
            'text' => '❌ Non eliminare',
            'callback_data' => 'donot'
        )
    );
        $menu1[] = array(
        array(
            'text' => '❌ Elimina',
            'callback_data' => 'getdel|' . $file
        )
    );
        $menu1[] = array(
        array(
            'text' => '❌ No, non farlo!',
            'callback_data' => 'donot'
        )
    );
        shuffle($menu1);
        cb_reply($cbid, 'Caricamento...', false, $cbmid, 'Vuoi davvero <b>eliminare</b> il file?', $menu1, 'HTML');
        exit;
    }
    if (strpos($cbdata, 'getdel') === 0 and $isadminbot == $userID and $chatID > 0) {
        $i    = explode('|', $cbdata);
        $file = $i[1];
        unlink('DATA/' . $file);
        cb_reply($cbid, 'Fatto!', false, $cbmid, '<b>' . $file . '</b> è stato <i>eliminato!</i>');
        exit;
    }
    if ($cbdata == 'donot' and $isadminbot == $userID and $chatID > 0) {
        cb_reply($cbid, 'Caricamento...', false, $cbmid, 'File <b>non</b> eliminato.');
    }
}
