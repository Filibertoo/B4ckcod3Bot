<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Feedback';
function Feedback_info()
{
    return 'Questo plugin permette di inviare un feedback agli admin del bot (Utilizza il comando <code>/feedback</code>).';
}
$annulla[] = array(
    array(
        'text' => 'Annulla',
        'callback_data' => 'annullafeedback'
    )
);
$replyText = $update['message']['reply_to_message']['text'];
if ($msg == '/feedback' and $u['Page'] != 'feedback') {
    setPage($userID, 'feedback');
    sm($userID, 'Invia ora il tuo feedback!', $annulla, 'HTML', false, 'default', true);
    exit;
}
if ($cbdata == 'annullafeedback') {
    setPage($userID);
    cb_reply($cbid, 'Okey!', false, $cbmid, 'Feedback annullato!');
    exit;
}
if ($u['Page'] == 'feedback' and $msg) {
    setPage($userID);
    if (!empty($username)) {
        $nome = $nome . ' (@' . $username . ')';
    }
    foreach ($adminbot as $ad) {
        sm($ad, "#Feedback\n\n<b>Utente:</b> " . $nome . ' [' . $userID . "]\n<b>Messaggio:</b> " . $msg . "\n<i>Per rispondere, rispondi a questo messaggio</i>", false, 'HTML', false, false, false);
    }
    sm($chatID, 'Grazie per il Feedback.', false, 'HTML', false, 'default', false);
    exit;
}
if (strpos($replyText, '#Feedback') === 0 and in_array($userID, $adminbot) and $msg) {
    preg_match_all('#\[(.*?)\]#', $replyText, $nomea);
    $replyToID = $nomea[1][0];
    sm($replyToID, '<b>Risposta al Feedback</b> da ' . $nome . '

' . $msg, false, 'HTML', false, false, false);
    sm($chatID, 'Inviato.');
    exit;
}
