<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'chat';
function chat()
{
    return 'Questo plugin permette di creare una chat tra gli utenti e gli admin.';
}
$adminChat = array(
	148769610, 263932373, 484091912//263932373, Aggiugi altri admin
);

function setChat($chatID, $Chat = '') //Funziona per settare On/Off la converazione
{
    global $table;
    global $db;
    $sth = $db->prepare('UPDATE ' . $table . ' SET Chat = :chat WHERE chat_id = ' . $chatID);
    $sth->bindParam(':chat', $Chat, PDO::PARAM_STR, 7);
    $sth->execute();
}
if ($chatID > 0){
    if ((($cbdata == "chatON" or strpos($msg, "/chat")===0)and $u['Page']!= "ban" and $msg!="🔚 Esci dalla Chat")){ //Chat Attivata
        $menu[] = array(
            "🔚 Esci dalla Chat"
        );
        $txt = "🗣 <b>Chat</b> 🗣\n\nOra sei in chat con gli admin. Usa il pulsante \"Esci dalla Chat\" per abbandonare la chat.";
        if($cbdata){
            cb_reply($cbid, "Chat Avviata", false, $cbmid, $txt, false, 'HTML');
            sm($userID, "<i>Utilizza la chat come una normale chat con un altra persona.</i>", $menu, 'HTML', false, false, false);
            } else {
            sm($chatID, $txt, false, 'HTML', false, false, false);
            sm($userID, "<i>Utilizza la chat come una normale chat con un altra persona.</i>", $menu, 'HTML', false, false, false);
            }
        setChat($userID, 'On');
        setPage($userID, 'Chat');
    }
    if ($msg == "🔚 Esci dalla Chat" and $u['Chat'] == 'On') { //Chat Disattivata
        $menu[] = array(
            array(
                'text' => '🔙 Indietro',
                'callback_data' => 'start'
            ),
        );
        setChat($userID, 'Off');
        setPage($userID, 'Uscito dalla chat');
        $txt = "🗣 <b>Chat</b> 🗣\n\nHai abbandonato la chat.";

        if($esci = sm($userID, $txt, 'nascondi', 'HTML', false, false)){
            $dec = json_decode($esci, true);
            $MSGID = $dec['result']['message_id'];
            deleteMessage($userID, $MSGID);
            sm($userID, $txt, $menu, 'HTML', false, true, true);
        }
    } elseif ($msg == "🔚 Esci dalla Chat" and $u['Chat'] != 'On'){
        sm($chatID, "🗣 <b>Assistenza</b> 🗣\n\nHai <b>già</b> abbandonato la chat.", 'nascondi', 'HTML');
    }
    if($msg and $u['Page'] == 'Chat'){ //Rispondi (Da amministratore) ad un messaggio inoltrato, anonimamente:
        $comandiEsclusi = [
        	'/ban', '/unban', '/start', '/admin', strpos($msg, "/")===0,  // Aggiugi altri comandi da escludere
        ];
    }
    if ((((strpos($u['Page'], 'Chat') === 0) and (strpos($u['Chat'], 'On') === 0))and $update) and $msg!= "🔚 Esci dalla Chat") {
        if ($msg and !in_array($msg, $comandiEsclusi)){
            foreach($adminChat as $ad) {
                forwardMessage($ad, $chatID, $messageID); //Questo ciclo invia i messaggi ad ogni $ad (ogni admin)
            }
            exit;
        }
        if (!$msg){
            foreach($adminChat as $ad) {
                forwardMessage($ad, $chatID, $messageID);  //Questo ciclo invia il contatto ad ogni $ad (ogni admin)
            }
            exit;
        }
    }

    if($replyID and $userID == $isadminbot){ //Rispondi (Da amministratore) ad un messaggio inoltrato, anonimamente:

        $namereply = $update['message']['reply_to_message']['forward_from']['first_name'];
        $reply_message_ID       = $update['message']['reply_to_message']['message_id'];
        $pos_array = intval(array_search($userID, $adminChat)); //Posizione nell' array dell' admin che risponde
        $msg_id_start = intval($reply_message_ID - ($pos_array*1));
        $comandiEsclusiAdmin = [//Comandi Esclusi dall' inoltro
        	'/ban', '/unban', '/start', strpos($msg, "/")===0, // Aggiugi altri comandi da escludere
        ];

        //Messaggi Testuali
        if($msg and !in_array($msg, $comandiEsclusiAdmin)) {
            if(sm($replyID, $msg, false, 'HTML', false, ($reply_message_ID-$pos_array)-1, false)){
                //Invia un messaggio agli altri admin con la risposta data dall' admin
                $i = 0;
                foreach($adminChat as $ad) {
                    if ($ad != $chatID){//Diverso dal chatid dell' admin che risponde
                        sm($ad, "L' admin <b>$nome</b> [<code>$chatID</code>] <b>ha risposto</b> a questo messaggio in questo modo:\n\n<i>" . $msg . "</i>", false, 'HTML', false, ($msg_id_start+$i), false);
                    }
                    $i++;//aumenta il message ID cosi da mandarlo ad ogni admin
                }
            }else{
                sm($userID, "L' utente <b>$namereply</b> [<code>$replyID</code>], ha <b>disattivato</b> il bot.", false, 'HTML', false, $reply_message_ID, false);
                setPage($replyID, 'disable');
            }
        }
        //Foto
        if($photo){
            if(sendPhoto($replyID, $photo, $caption, 'HTML', false, ($reply_message_ID-$pos_array)-1, false)){
                //Invia un messaggio agli altri admin con la risposta data dall' admin
                $i = 0; $k=2;
                foreach($adminChat as $ad) {
                    if ($ad != $chatID){//Diverso dal chatid dell' admin che risponde
                        $pp= sendPhoto($ad, $photo, $caption, 'HTML', false, ($msg_id_start+$i), false);
                        $Decodifico = json_decode($pp, true);
                        $Estraggo_MSGID = $Decodifico['result']['message_id']; #id preview
                        sm($ad, "L' admin <b>$nome</b> [<code>$chatID</code>] <b>ha risposto</b> ha risposto al messaggio citato in questo modo.", false, 'HTML', false, $Estraggo_MSGID, false);
                    }
                    $k=$k+2;
                    $i++;//aumenta il message ID cosi da mandarlo ad ogni admin
                }
            }else{
                sm($userID, "L' utente <b>$namereply</b> [<code>$replyID</code>], ha <b>disattivato</b> il bot.", false, 'HTML', false, $reply_message_ID, false);
                setPage($replyID, 'disable');
            }
        }

        if($audio)                                         {sendAudio($replyID, $audio, $caption, 'HTML', false, false, false, false);}
        if($voice)                                         {sendVoice($replyID, $voice, $caption, 'HTML', false, false, false, false);}
        if($video)                                         {sendVideo($replyID, $video, $caption, 'HTML', $duration, $width, $height, $video_caption, 'HTML', false, false, false);}
        if($video_note)                                    {sendVideoNote($replyID, $video_note, false, 'HTML', false, false, false);}
        if($document)                                      {sendDocument($replyID, $document, $caption, 'HTML', false, false, false, false);}
        if($sticker)                                       {sendSticker($replyID, $sticker, false, 'HTML', false, false, false);}
        if($location)                                      {sendLocation($replyID, $latitude, $longitude, false, 'HTML', false, false, false);}
        if($venue)                                         {sendVenue($replyID,  $latitude, $longitude, $title, $address, $foursquare_id, false, 'HTML', false, false, false);}
        if($contact)                                       {sendContact($replyID,  $phone_number, $first_name, $last_name, false, 'HTML', false, false, false);}

    }
    //Ban e Unban
    if($msg == "/ban" and $userID == $isadminbot)
    {
        setPage($replyID, "ban");
        sm($userID, "🗣 <b>Chat</b> 🗣\n\nHai bannato <b>$replyID</b>!", true, 'HTML', false, false, true); //admin
        sm($replyID, "🗣 <b>Chat</b> 🗣\n\nSei stato bannato da <b>$userbot</b>!", true, 'HTML', false, false, false); //User
    }
    if($msg == "/unban" and $userID == $isadminbot)
    {
        setPage($replyID, "");
        sm($userID, "🗣 <b>Chat</b> 🗣\n\nHai sbannato <b>$replyID</b>!", true, 'HTML', false, false, true); //admin
        sm($replyID, "🗣 <b>Chat</b> 🗣\n\nSei stato sbannato da <b>$userbot</b>!", true, 'HTML', false, false, false);
    }
}
