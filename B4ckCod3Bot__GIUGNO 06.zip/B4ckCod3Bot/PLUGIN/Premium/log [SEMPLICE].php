<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Log';
function Log_info()
{
    return 'Questo plugin invia in un canale tutti i messaggi che riceve nel bot (Il bot deve essere admin del canale LOG). | Versione 1.0';
}
$canaleLOG = -1001317299676; //ID canale a cui mandare i log (- Obbligatorio)
$comandiEsclusiLOG = [ //Comandi da escludere che non verranno loggati
  '/start',
];
$utentiEsclusiLOG = [ //ID Utenti da escludere di cui tutti i messaggi non verranno loggati
    //000000000,//000000000,
];
if($msg and !$cbdata and !in_array($msg, $comandiEsclusiLOG) and !in_array($userID, $utentiEsclusiLOG))
{
    if($username) $manda = "@".$username;
    else $manda = $nome;
    $BotProvenienza = "@".$userbot;
    sendMessage($canaleLOG, "🗳 <b>Log Messaggi</b> 🗳\n\n🤖 <b>Bot di Provenienza</b>: $BotProvenienza\n👤 <b>User</b>: $nome ($manda) [$userID]\n✉️ <b>Messaggio</b>: $msg", 'HTML', 'default', false, false);
}
