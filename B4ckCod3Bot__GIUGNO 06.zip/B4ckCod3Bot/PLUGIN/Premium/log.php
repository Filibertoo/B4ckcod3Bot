<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Log';
function Log_info()
{
    return 'Questo plugin invia in un canale tutti i tipi di messaggi che riceve nel bot (Il bot deve essere admin del canale LOG). | Versione 2.0';
}
// =========================== [ Impostazioni LOG ] ===========================
$canaleLOG = -1001398304495; //ID canale a cui mandare i log (- Obbligatorio)
$utentiEsclusiLOG = [ //ID Utenti da escludere di cui tutti i messaggi non verranno loggati
    184927310,//000000000,
];
$LOG = array(
    'Nuovi_Utenti'           => false,  #Logga tutti i nuovi utenti che aprono il bot
    'Messaggi'               => true,   #Logga Messaggi
    'Foto'                   => true,   #Logga inoltrando le foto inviate al bot
    'Sticker'                => true,   #Logga inoltrando gli stiker inviati al bot
    'Audio'                  => true,   #Logga inoltrando i file audio inviati al bot
    'File'                   => true,   #Logga inoltrando i file inviati al bot
    'Ban_Unban'              => false,  #Logga ogni utente che viene bannato/sbannato
    'Inoltra_Messaggi'       => false,  #Per inoltare i messeggi testuali di un utente nel canale log
    'TAG'                    => true,   #Per mostrare i tag a fine messaggio log
);
// =========================== [ Impostazioni LOG ] ===========================

$token = explode(":", $_GET['api']);
$bot = $token[0];
$ex = explode("bot", $token[0]);
$botID = $ex[1];
$Page = $u['Page'];

//TAG Messaggi LOG
if($LOG['TAG'] == true){
    $TAG = "\n\nTAG | #id$userID #$bot #$bot"."_$userID";
} else {
    $TAG = "";
}

if ($chatID > 0){
    //Log Nuovi Utenti
    if($LOG['Nuovi_Utenti'] == true){

        $CercaUtente = json_decode(file_get_contents('DATA/_user.json'), true);
        $ID_Utenti_File = $CercaUtente['ID_User'];
        $trova = array_search($userID, $CercaUtente);

        if($msg == '/start' and !in_array($userID, $ID_Utenti_File)) #Se non è presente nel database lo loggo
        {
            sm($chatID, "\n\n$CercaUtente");
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            sendMessage($canaleLOG, "➕ #NUOVO_UTENTE\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>] $TAG", 'HTML', 'default', false, false);
            file_put_contents('../DATA/_user.json', json_encode($userID)); //Scrivo in _user.json l'utente
            exit;
        } elseif($msg == '/start' and in_array($userID, $ID_Utenti_File)) {
            sm($chatID, 'gia nel file');
        }
    }

    //Log Messaggi
    if($LOG['Messaggi'] == true){
        $MessaggiEsclusiLOG = [ //Comandi da escludere che non verranno loggati
          '/start',
        ];
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        $inlineupdate = $update['inline_query']; //Per far in modo che non vengao loggati gli update da inline_query
        if((($msg and !$cbdata and !in_array($msg, $MessaggiEsclusiLOG) and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG)) and $update != $inlineupdate)
        {
            //Inoltra Messaggio
            if ($LOG['Inoltra_Messaggi'] == true){
                forwardMessage($canaleLOG, $chatID, $messageID);
            }
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            sendMessage($canaleLOG, "📨 #NUOVO_MESSAGGIO\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page\n<b>MESSAGGIO</b>: <i>$msg</i> $TAG", 'HTML', 'default', false, false);
        }
    }

    //Log Foto
    if ($LOG['Foto'] == true){
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        if(($photo and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG))
        {
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            forwardMessage($canaleLOG, $chatID, $messageID);
            sendMessage($canaleLOG, "🖼 #NUOVA_FOTO\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page $TAG", 'HTML', 'default', false, false);
        }
    }

    //Log Stiker
    if ($LOG['Sticker'] == true){
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        if(($sticker and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG))
        {
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            forwardMessage($canaleLOG, $chatID, $messageID);
            sendMessage($canaleLOG, "🗃 #NUOVO_STICKER\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page $TAG", 'HTML', 'default', false, false);
        }
    }

    //Log Video
    if ($LOG['Video'] == true){
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        if(($video and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG))
        {
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            forwardMessage($canaleLOG, $chatID, $messageID);
            sendMessage($canaleLOG, "🎞 #NUOVO_VIDEO\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page $TAG", 'HTML', 'default', false, false);
        }
    }

    //Log Audio
    if ($LOG['Audio'] == true){
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        if((($audio or $voice) and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG))
        {
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            forwardMessage($canaleLOG, $chatID, $messageID);
            sendMessage($canaleLOG, "🎙 #NUOVO_AUDIO\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page $TAG", 'HTML', 'default', false, false);
        }
    }

    //Log File
    if ($LOG['File'] == true){
        //Page scomposte ad esempio Test_sdufs0d
        $PageScomposta = explode("_",$u['Page']);
        $PageTest = $PageScomposta[0] == 'Test';
        $pageEscluseLOG = [ #Per escludere i messaggi inviati se ci si trova in una determinata Posizione (Page del database)
            'Consigli', 'Segnalazione', $PageTest, //altrePage
        ];
        if(($document and !in_array($userID, $utentiEsclusiLOG)) and !in_array($u['Page'], $pageEscluseLOG))
        {
            if($username) $manda = "@".$username;
            else $manda = $nome;
            $BotProvenienza = "@".$userbot;
            forwardMessage($canaleLOG, $chatID, $messageID);
            sendMessage($canaleLOG, "🗂 #NUOVO_FILE\n\n<b>UTENTE</b>: <a href=\"https://t.me/$username\">$nome</a> [<code>$userID</code>]\n<b>BOT</b>: <a href=\"https://t.me/$userbot\">$userbot</a> [<code>$botID</code>]\n<b>PAGE DATABASE</b>: $Page $TAG", 'HTML', 'default', false, false);
        }
    }
}
