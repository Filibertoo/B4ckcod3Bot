<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Inoltro nei canali';
function Inoltro_nei_canali_info()
{
    return 'Questo plugin permette di inoltrare automaticamente i messaggi di un canale ad un gruppo. | Versione 1.0';
}

$PluginFileName = basename(__FILE__); //Return the name of current file.php
$File_Forward = '_' . explode('.', $PluginFileName)[0] . '.json'; //Return name of file (without extension)
$firma = false; #Metti true se vuoi utilizzare una firma per i tuoi messaggi
$firma_messaggi = 'firma'; #Inserisci la firma

$canale_da_cui_inoltrare = -1009877989844; //Inserisci ID canale (- Obbligatorio)
$gruppo_in_cui_inoltrare = -1001777887896; //Inserisci ID gruppo (- Obbligatorio)

$chat_id_channel    = $update['channel_post']['chat']['id'];
$message_id_channel = $update['channel_post']['message_id'];
$text_msg_channel   = $update['channel_post']['text'];
$type_chat          = $update['message']['chat']['type'];

$gruppi_bannati = [
    -234324, -23432
];
//Aggiungi gruppi

if ($chatID < 0 and $type_chat == 'supergroup'){

    if (!in_array($chatID, $gruppi_bannati)){ //Se il gruppo non è tra i bannati
        $save_this_id[] = $chatID;
        if(!file_exists('DATA/'.$File_Forward)){ #Se il file non esiste
            file_put_contents('DATA/'.$File_Forward, json_encode($save_this_id, true)); //Creo e scrivo il file con l'id del gruppo
        } elseif(file_exists('DATA/'.$File_Forward)) { #Se il file esiste già
            $array_id_gruppi = json_decode(file_get_contents('DATA/'.$File_Forward), true);
            if (!in_array($chatID, $array_id_gruppi)){ #Se l'ID del gruppo non è stato ancora inserito
                $array_id_gruppi[] = $chatID; #prova chia it
                file_put_contents('DATA/'.$File_Forward, json_encode($array_id_gruppi, true)); //Creo e scrivo il file con l'id del gruppo
            }
        }
    } else {
        leaveChat($chatID);
    }
}

//Inoltra i post
if($update['channel_post'] and $chat_id_channel == $canale_da_cui_inoltrare){

    if ($firma == true){ #Se è richiesta una firma nei messaggi

        $signature = substr($text_msg_channel, -strlen($firma_messaggi));
        if ($signature == $firma_messaggi){
            $ID_gruppi = json_decode(file_get_contents('DATA/'.$File_Forward), true); //Decodifica il json del file dove ci sono tutti gli id dei gruppi
            foreach ($ID_gruppi as $gruppo) {
                if(forwardMessage($gruppo, $canale_da_cui_inoltrare, $message_id_channel, true)){
                    $new_ids[] = $gruppo;
                } else {
                    if (empty($new_ids)){
                        $new_ids = array();
                    }
                }
            }
            file_put_contents('DATA/'.$File_Forward, json_encode($new_ids, true));
        }
    } else {  #Se NON è richiesta una firma nei messaggi

        $ID_gruppi = json_decode(file_get_contents('DATA/'.$File_Forward), true); //Decodifica il json del file dove ci sono tutti gli id dei gruppi
        foreach ($ID_gruppi as $gruppo) {
            if(forwardMessage($gruppo, $canale_da_cui_inoltrare, $message_id_channel, true)){
                $new_ids[] = $gruppo;
            } else {
                if (empty($new_ids)){
                    $new_ids = array();
                }
            }
        }
        file_put_contents('DATA/'.$File_Forward, json_encode($new_ids, true));
    }
}
