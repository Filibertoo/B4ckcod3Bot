<?php
/*
    Copyright (C) 2018 B4ckCod3Bot

    B4ckCod3Bot is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    B4ckCod3Bot is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

$plugin = 'Bacheca';
function bacheca_info()
{
    return 'Questo plugin crea una bacheca che è possibile gestire direttamente dal menù admin, nella sezione plugin.';
}
$PluginFileName = basename(__FILE__); //Return the name of current file.php
$FileTemp = "temp_" . explode('.', $PluginFileName)[0] . '.json'; //Return name of file (without extension)
$cb_apri_bacheca = 'ApriBachecaUtenti'; //Insert the name for call back the board

$ID = explode("_", $update["callback_query"]["data"]); //Scomponi callback_data
$PageScomposta = explode("_",$u['Page']); //Scomponi page db

// ====== [ Crate Table ] =======
$boardName = "Board_".$table;
if ($boardName != 'Board_'){
    $db->exec("CREATE TABLE IF NOT EXISTS $boardName (
        `ID` int(0) NOT NULL AUTO_INCREMENT,
        `Date` DATETIME DEFAULT CURRENT_TIMESTAMP, -- Data di creazione dell' articolo, formato d/m/y
        `Name_Article` varchar(300) DEFAULT '', -- Nome dell' aritcolo, massimo 25 caratteri
        `Text_Article` text,
        `Formatting` varchar(8) DEFAULT 'HTML', -- Formattazione del testo settata di default in HTML
        `Disable_Link_Preview` bit(1) DEFAULT 0, -- Anteprima link settada di default su 0, quindi si vedranno le anteprime
        `Hide` bit(1) DEFAULT 0, --  o rendi visualizzabile l'articolo di default su 0
        `Visual` int NOT NULL DEFAULT 0, -- Numero di volte totali che è stato visualizzato l'articolo (si aggiorna ogni volta che qualcuno apre l'articolo)
        PRIMARY KEY (`ID`));"
    );
}
// ====== [ Exlusive Function ] =======
function send_message_preview_article($chatID, $text, $rmf = false, $pm = 'pred', $hide_preview = false, $dis = false, $replyto = 'default', $inline = 'pred')
{
    global $API;
    global $api;
    global $userID;
    global $update;
    global $config;

    if ($pm == 'pred') {
        $pm = $config['formattazione_predefinita'];
    }
    if ($replyto == 'default' and $config['risposta_automatica'] === true) {
        $replyto = $update['message']['message_id'];
    } elseif ($replyto == 'default') {
        $replyto = false;
    }
    if ($inline == 'pred') {
        if ($config['tastiera_predefinita'] == 'inline') {
            $inline = true;
        } elseif ($config['tastiera_predefinita'] == 'normale') {
            $inline = false;
        }
    }
    if ($rmf == '') {
        $inline = false;
    }

    if (!$inline) {
        if ($rmf == '') {
            $rm = array(
                'hide_keyboard' => true
            );
        } else {
            $rm = array(
                'keyboard' => $rmf,
                'resize_keyboard' => true
            );
        }
    } else {
        $rm = array(
            'inline_keyboard' => $rmf
        );
    }
    $rm   = json_encode($rm);
    $args = array(
        'chat_id' => $chatID,
        'text' => $text,
        'disable_notification' => $dis,
        'parse_mode' => $pm
    );
    if ($hide_preview) {
        $args['disable_web_page_preview'] = $hide_preview;
    }
    if ($replyto) {
        $args['reply_to_message_id'] = $replyto;
    }
    if ($rmf) {
        $args['reply_markup'] = $rm;
    }
    if ($text) {
        $rr   = post('post', $API . 'sendMessage', $args);
        $ar   = json_decode($rr, true);
        $ok   = $ar['ok'];
        $e403 = $ar['error_code'];
        if ($e403 == '403') {
            return false;
        } elseif ($e403) {
            return false;
        } else {
            return $rr;
        }
    }
}

function edit_message_preview_article($id, $text, $alert = false, $cbmid = false, $ntext = false, $nmenu = false, $npm, $hide_preview = false, $fordb)
{
    global $api;
    global $API;
    global $chatID;
    global $config;
    global $update;

    $args = array(
        'callback_query_id' => $id,
        'text' => $text,
        'show_alert' => $alert
    );

    $r    = post('post', $API . 'answerCallbackQuery', $args);
    if ($cbmid) {
        if ($nmenu) {
            $rm = array(
                'inline_keyboard' => $nmenu
            );
            $rm = json_encode($rm);
        }
        $args = array(
            'chat_id' => $chatID,
            'message_id' => $cbmid,
            'text' => $ntext,
            'disable_web_page_preview' => $hide_preview
        );
        if ($npm != 'nothing') {
            if ($npm == 'pred') {
                $npm = $config['formattazione_predefinita'];
            }
            $args['parse_mode'] = $npm;
        }
        if ($nmenu) {
            $args['reply_markup'] = $rm;
        }
        $r = post('post', $API . 'editMessageText', $args);
    }
}

function remove_formatting($nome)
{
    $nome = str_replace("<i>", "", $nome);
    $nome = str_replace("</i>", "", $nome);
    $nome = str_replace("<b>", "", $nome);
    $nome = str_replace("</b>", "", $nome);
    $nome = str_replace("<a href=\"", "", $nome);
    $nome = str_replace("\">", "", $nome);
    $nome = str_replace("</a>", "", $nome);
    $nome = str_replace("</>", "", $nome);
    $nome = str_replace("\n", " ", $nome);

    $nome = str_replace("*", "", $nome);
    $nome = str_replace("_", "", $nome);
    $nome = str_replace("\"", "&quot;", $nome);
    $nome = str_replace("'", "&quot;", $nome);
    //$nome = str_replace("/", "", $nome);
    return $nome;
}

function CreaMenu_Scorrevole($callback_data, $offset){

    global $boardName;
    global $db;

    $n = intval(explode(' ', $callback_data)[1])*$offset;
    $max = $db->query('SELECT COUNT(ID) FROM ' . $boardName)->fetchColumn();
    $n = ($n >= $max) ? 0 : $n;
    $res = $db->query("SELECT * FROM $boardName WHERE `Hide` != 1 ORDER BY `ID` DESC LIMIT $offset OFFSET $n");

    $menu = array();
    while($row = $res->fetch(PDO::FETCH_ASSOC)){
        $menu[] = array(
            array(
                'text' => json_decode($row['Name_Article'], true),
                'callback_data' => 'VisualizzaArticoloUTENTE_' . $row['ID']
            )
        );
    }
    if($n == 0 && $n+$offset < $max){
        $menu[] = array(
            array(
                'text' => 'Pagina ' . ($n/$offset + 2) . ' ➡',
                'callback_data' => 'pagina '.($n/$offset +1)
            )
        );
    }elseif($n+$offset >= $max && $n > 0){
        $menu[] = array(
            array(
                'text' => '⬅ Pagina ' . ($n/$offset),
                'callback_data' => 'pagina ' . ($n/$offset -1)
            )
        );
    }elseif($n > 0 && $n + $offset < $max){
        $menu[] = array(
            array(
                'text' => '⬅ Pagina ' . ($n/$offset),
                'callback_data' => 'pagina ' . ($n/$offset -1)
            ),
            array(
                'text' => 'Pagina '.($n/$offset + 2) . ' ➡',
                'callback_data' => 'pagina ' . ($n/$offset +1)
            )
        );
    }
    return $menu;
}

// ==================================================== [ End of functions ] ====================================================


$MessaggiEsclusiBoard = [
    '/admin', '/start', '/aggiungiarticolo',
];

// ====== [ Board Menù ] =======
if(($cbdata == $PluginFileName or strpos($msg, "/boardmenu")===0) and $userID == $isadminbot and $chatID > 0) {
    $menu[] = array(
        array(
            'text' => '📄 Articoli Creati 📄',
            'callback_data' => 'BoardArticoliCreati'
        )
    );
    $menu[] = array(
        array(
            'text' => '➕ Aggiungi',
            'callback_data' => 'BoardAggiungiArticolo'
        ),
        array(
            'text' => 'Elimina ➖',
            'callback_data' => 'BoardEliminaArticolo'
        )
    );
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => 'ConfigurazionePlugins'
        )
    );
    $txt = "📋 <b>Board Menù</b> 📋\n\n<i>Gestisci da questo menù la bacheca del bot.</i>\n\n📄 <b>Visualizza e gestisci</b> gli articoli che hai creato.\n➕ <b>Aggiugi</b> nuovo articolo.\n➖ <b>Elimina</b> articolo già esistente.";
    if($cbdata){
        cb_reply($cbid, 'Board Menù', false, $cbmid, $txt, $menu, 'HTML');
    } else{
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
    }
    setPage($userID, 'BoardMenu');
}


/*------------------------------
Aggiungi articolo
------------------------------*/
// ====== [ Add Article To Board - Step 1 ] =======
if((($cbdata == "BoardAggiungiArticolo" or strpos($msg, "/aggiungiarticolo")===0) or $ID[0] == 'FormattazioneArticolo') and $userID == $isadminbot and $chatID > 0) {

    //Elimina file $FileTemp se esistente
    unlink($FileTemp);

    //Formattazione Testo Articolo
    if ($ID[0] == 'FormattazioneArticolo'){
        if ($ID[1] == 'HTML') $changeformatting = 'Markdown'; elseif ($ID[1] == 'Markdown') $changeformatting = 'HTML';
        $formattazione = $changeformatting;
    } else {
        $formattazione  =  $config['formattazione_predefinita'];
    }
    $menu[] = array(
        array(
            'text' => 'Formattazione: ' . $formattazione,
            'callback_data' => 'FormattazioneArticolo_' . $formattazione
        )
    );

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => $PluginFileName
        )
    );
    $txt = "➕ <b>Aggiungi Articolo</b> ➕\n\n<i>Da qui puoi aggiungere i tuoi articoli alla bacheca.</i>\n\nInvia il <b>testo</b> dell' articolo che vuoi aggiungere nella bacheca.";
    if($cbdata){
        cb_reply($cbid, 'Aggiungi Articolo', false, $cbmid, $txt, $menu, 'HTML');
    } else{
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
    }
    setPage($userID, 'AggiungiArticolo_' . $formattazione);
}


// ====== [ Add Article To Board - Step 2 ] =======
if (((($PageScomposta[0] == 'AggiungiArticolo' and $msg) or $ID[0] == 'AnteprimaArticolo') or $ID[0] == 'BackAnteprima') and $userID == $isadminbot and $chatID > 0){

    $formattazione = $PageScomposta[1];

    /*  INDICE
        $PageScomposta[1] ----> formattazione solo alla prima anteprima del messaggio
        ==========================
        $PageScomposta[1] ----> true o false per nascondere o meno l'anteprima
        $PageScomposta[2] ----> ID del messaggio da modificare per l'anterpima
        $PageScomposta[3] ----> Messaggio di conferma
        $PageScomposta[4] ----> Serve per passare il tipo di formattazione
    */

    //Da messaggio
    if(!in_array($msg, $MessaggiEsclusiBoard)){

        //Questo menu e questo testo va in tutti i messaggi
        $txt = "➕ <b>Aggiungi Articolo</b> ➕\n\nEcco l' <b>anteprima</b> di come il tuo articolo comparirà in bacheca, <b>invia</b> il <b>nome del pulsante</b> che gli utenti visualizzeranno prima di aprire l' articolo.";

        if ($PageScomposta[0] == 'AggiungiArticolo' and $msg){

            if ($config['nascondi_anteprima_link'] == true) {$preview = 'Si';} else {$preview = 'No';}

            $menu[] = array(
                array(
                    'text' => 'Nascondi Anteprima Link: ' . $preview,
                    'callback_data' => 'AnteprimaArticolo_' . $preview
                )
            );
            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BoardAggiungiArticolo'
                )
            );

            if ($MessaggioDiPreview = send_message_preview_article($chatID, $msg, false, $formattazione, $config['nascondi_anteprima_link'], false, false, true)){ //Preview di default se la formattazione è corretta

                //Crea file per memorizzare temporeaneamete il messaggio
                $myfile = fopen($FileTemp, "w") or die("Unable to open file!");
                $encode = json_encode($msg, true);
                fwrite($myfile, $encode);
                fclose($myfile);
                //-------------------
                $Decodifico_MessaggioDiPreview = json_decode($MessaggioDiPreview, true);
                $Estraggo_MSGID_MessaggioDiPreview = $Decodifico_MessaggioDiPreview['result']['message_id']; #id preview

                $RichiestaDiConferma = sm($chatID, $txt, $menu, 'HTML', false, false, true);
                $Decodifico_RichiestaDiConfermaw = json_decode($RichiestaDiConferma, true);
                $Estraggo_MSGID_RichiestaDiConferma = $Decodifico_RichiestaDiConfermaw['result']['message_id'];

                setPage($userID, 'AnteprimaArticolo_' . $preview . '_' . $Estraggo_MSGID_MessaggioDiPreview . '_' . $Estraggo_MSGID_RichiestaDiConferma . '_' . $formattazione);
            } else {
                $erroback[] = array(
                    array(
                        'text' => '🔙 Indietro',
                        'callback_data' => 'BoardAggiungiArticolo'
                    )
                );
                $txterror = "➕ <b>Aggiungi Articolo</b> ➕\n\n<i>Formattazione del testo non corretta, probabilmente hai sbagliato qualcosa nella sintassi.</i>\n\n<b>Reinvia</b> il testo formattato in modo corretto.";
                sm($chatID, $txterror, $erroback, 'HTML', false, false, true);
            }
        }

        //Da Callback per cambiare l' anteprima dei link
        if ($ID[0] == 'AnteprimaArticolo'){
            if ($ID[1] == 'Si') {$preview = 'No'; $pre = false;} elseif ($ID[1] == 'No') {$preview = 'Si'; $pre = true;}


            $menu[] = array(
                array(
                    'text' => 'Nascondi Anteprima Link: ' . $preview,
                    'callback_data' => 'AnteprimaArticolo_' . $preview
                )
            );
            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BoardAggiungiArticolo'
                )
            );
            $msgUtente = json_decode(file_get_contents($FileTemp), true);
            edit_message_preview_article($PageScomposta[2], 'Aggiungi Articolo', false, $PageScomposta[2], $msgUtente, false, $PageScomposta[4], $pre); //dovrebbe modificare il mex de'utente
            cb_reply($PageScomposta[3], 'Nascondi Anteprima Link: ' . $preview, false, $PageScomposta[3], $txt, $menu, 'HTML');

            setPage($userID, 'AnteprimaArticolo_' . $preview . '_' . $PageScomposta[2] . '_' . $PageScomposta[3] . '_' . $PageScomposta[4]); //Il primo page scomposta è l'id del messaggio da modificare dell'utnete mentre il sendo è del messagggio di conferma
        }

        //Da BackAnteprima in casi eccezzionali dove si sbaglia il nome del pulsante e si vuole tornare indietro
        if ($ID[0] == 'BackAnteprima'){

            //Non fa lo switch con l'ateprima perchè deve visualizzare quella salvata precedentemente
            if ($ID[1] == 'Si') {$preview = 'Si'; $pre = true;} elseif ($ID[1] == 'No') {$preview = 'No'; $pre = false;} //al cotnraorio eprche sono quelli dell'ultimo settaggio

            $menu[] = array(
                array(
                    'text' => 'Nascondi Anteprima Link: ' . $preview, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
                    'callback_data' => 'AnteprimaArticolo_' . $preview
                )
            );
            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BoardAggiungiArticolo'
                )
            );
            $msgUtente = json_decode(file_get_contents($FileTemp), true);
            $BackPreview = edit_message_preview_article($cbmid, 'Indietro', false, $cbmid, $msgUtente, false, $PageScomposta[4], $pre);
            $Decodifico_MessaggioDiPreview = json_decode($BackPreview, true);//return the message of user
            $Estraggo_MSGID_MessaggioDiPreview = $Decodifico_MessaggioDiPreview['result']['message_id']; #id preview

            $BackConferma = sm($chatID, $txt, $menu, 'HTML', false, false, true);
            $Decodifico_RichiestaDiConfermaw = json_decode($BackConferma, true);
            $Estraggo_MSGID_RichiestaDiConferma = $Decodifico_RichiestaDiConfermaw['result']['message_id'];

            setPage($userID, 'AnteprimaArticolo_' . $preview . '_' . $cbmid . '_' . $Estraggo_MSGID_RichiestaDiConferma . '_' . $ID[4]);
        }
    } //Messaggi esclusi
}

// ====== [ Add Article To Board - Step 3 ] =======
if (($PageScomposta[0] == 'AnteprimaArticolo' and $msg) and $userID == $isadminbot and $chatID > 0){

    $preview        = $PageScomposta[1];
    $MSGID_preview  = $PageScomposta[2];
    $MSGID_conferma = $PageScomposta[3];
    $formattazione  = $PageScomposta[4];

    if(!in_array($msg, $MessaggiEsclusiBoard)){
        $caratterimsg = strlen($msg); //return the number of characters of msg
        if ($caratterimsg > 200){

            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BackAnteprima_' . $preview . '_' . $MSGID_preview . '_' . $MSGID_conferma . '_' . $formattazione
                )
            );
            $txt = "➕ <b>Aggiungi Articolo</b> ➕\n\n<i>Nome del pulsante troppo lungo.</i>\n\n<b>Reinvia</b> il nome del pulsante.";
            sm($chatID, $txt, $menu, 'HTML', false, false, true);
        } elseif ($caratterimsg <= 200) {
            $menu[] = array(
                array(
                    'text' => 'Conferma ✅',
                    'callback_data' => 'ConfermaCreazioneArticolo_' . $msg
                )
            );
            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BackAnteprima_' . $preview . '_' . $MSGID_preview . '_' . $MSGID_conferma . '_' . $formattazione
                )
            );
            $txt = "➕ <b>Aggiungi Articolo</b> ➕\n\n<i>Nome del pulsante impostato.</i>\n\nPremi <b>conferma</b> per confermare la creazione dell' articolo.";
            sm($chatID, $txt, $menu, 'HTML', false, false, true);
            setPage($userID, 'NomePulsante_' . $preview . '_' . $MSGID_preview . '_' . $MSGID_conferma . '_' . $formattazione);
        }
    }
}

// ====== [ Add Article To Board - Step 4 ] =======
if ($ID[0] == 'ConfermaCreazioneArticolo' and $userID == $isadminbot and $chatID > 0){

    $preview        = $PageScomposta[1]; if ($PageScomposta[1] == 'Si') {$preview = true;} elseif ($PageScomposta[1] == 'No') {$preview = false;}
    $MSGID_preview  = $PageScomposta[2];
    $MSGID_conferma = $PageScomposta[3];
    $formattazione  = $PageScomposta[4];
    $NomePulsante   = json_encode($ID[1], true); //va encodato per salvarlo nel DB
    $TestoArticolo  = file_get_contents($FileTemp); //viene salvato ancora encodato in json per salvarlo correttamente nel DB

    // ==== [ Creating Row ] ====
    $sth = $db->prepare("INSERT INTO $boardName (Name_Article, Text_Article, Formatting, Disable_Link_Preview) VALUES (:name_article, :text_article, :formatting, :preview)");
    $sth->bindParam(':name_article', $NomePulsante, PDO::PARAM_STR, 7); //ChatID dell' utente
    $sth->bindParam(':text_article', $TestoArticolo, PDO::PARAM_STR, 7); //ID Bot
    $sth->bindParam(':formatting', $formattazione, PDO::PARAM_STR, 7); //Token
    $sth->bindParam(':preview', $preview, PDO::PARAM_STR, 7); //UsernameBot
    $sth->execute();
    unlink($FileTemp);

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => $PluginFileName
        )
    );

    $txt = "➕ <b>Aggiungi Articolo</b> ➕\n\nArticolo <b>creato con successo</b>! Esso è stato <b>aggiunto</b> correttamente in bacheca e sarà presto visualizzabile dagli utenti! Puoi <b>personalizzare</b> l'articolo dal suo personale centro di controllo.";
    cb_reply($cbid, 'Board Menù', false, $cbmid, $txt, $menu, 'HTML');
}


/*------------------------------
Articoli Creati
------------------------------*/
if((($cbdata == "BoardArticoliCreati" or strpos($msg, "/articoli")===0) or $ID[0] == 'NextPage') and $userID == $isadminbot and $chatID > 0) {

    //Creazione Pulsanti
    $robe = array();
	$valori = array();
	$AddPulsBot = $db->query('SELECT * FROM `' . $boardName . '` ORDER BY `ID` DESC');
	if(isset($AddPulsBot) && $AddPulsBot) {
		$i = 1;
		while($Associa = $AddPulsBot->fetch(PDO::FETCH_ASSOC)) {
            $ID_Article = $Associa['ID'];
			$Name_Article = $Associa['Name_Article']; //viene decodificato il json salvato nel DB
            $AmministratoreBOT = $Associa['Chat_ID'];
			$valori[] = $ID_Article;
			$robe[$i] = $Name_Article;
			$i++;
		}

        //Dall 'inizio '
		$n = 1;
		$k = 0;
		$i = 1;
		$limite_riga = 1;
		foreach ($valori as $ID_art) {
			if($n > $limite_riga) {
				$n = 1;
				$k++;
			};
			$Name_Article = json_decode($robe[$i], true);
			$menu[$k][]=
				array(
					'text'=> $Name_Article,
					'callback_data' => 'VisualizzaArticolo_' . $ID_art
				);
			$n++;
			$i++;
		}
    }
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => $PluginFileName
        )
    );
    $txt = "📄 <b>Articoli Creati</b> 📄\n\n<i>Da qui puoi visualizzare e gestire ogni singolo articolo che hai creato.</i>";
    if($cbdata){
        cb_reply($cbid, 'Articoli Creati', false, $cbmid, $txt, $menu, 'HTML');
    } else{
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
    }
    setPage($userID, 'Articoli Creati');
}

// ====== [ Visualizza Articoli ] =======
if ($ID[0] == 'VisualizzaArticolo' and $userID == $isadminbot and $chatID > 0){

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    //========== Informazioni Articolo
    $Date = $Associa['Date'];
    $Button = json_decode($Associa['Name_Article'], true); //decodifico il json
    $Text_Article = json_decode($Associa['Text_Article'], true); //decodifico il json
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];
    $Hide_Article = $Associa['Hide'];
    $Visual = $Associa['Visual'];
    //========== Informazioni Articolo

    //Modifica messaggio con quello per vedere la preview
    edit_message_preview_article($cbmid, $Associa['Name_Article'], false, $cbmid, $Text_Article, false, $Formatting, $Disable_Link_Preview);

    //tasti di personalizzazione
    $menu[] = array(
        array(
            'text' => '🎈 Bottone',
            'callback_data' => 'ModificaBottone_' . $ID[1]
        ),
        array(
            'text' => 'Testo ✏️',
            'callback_data' => 'ModificaTesto_' . $ID[1]
        )
    );

    //Per disabilitare/abilitare l'anteprima dei link
    if ($Disable_Link_Preview == 1) {$preview = 'Si';} elseif ($Disable_Link_Preview == 0) {$preview = 'No';}
    $menu[] = array(
        array(
            'text' => 'Nascondi Anteprima Link: ' . $preview, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'ModificaAnteprimaArticolo_' . $preview . '_' . $cbmid . '_' . $ID[1]
        )
    );
    //Per disabilitare/abilitare la visaulizzazione delle notiza in bacheca per gli utenti
    if ($Hide_Article == 1) $Hide = 'Si'; else $Hide = 'No';
    $menu[] = array(
        array(
            'text' => '👁‍🗨 Oscura Articolo: ' . $Hide, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'OscuraArticolo_' . $Hide  . '_' . $ID[1] . '_' . $cbmid
        )
    );

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => 'BoardArticoliCreati'
        )
    );
    $txt = "📄 <b>Articoli Creati</b> 📄\n\n<i>Ecco l' anteprima dell' articolo e le relative informazioni.</i>\n\n<b>Bottone</b>: $Button\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Visualizzazioni</b>: $Visual";
    sm($chatID, $txt, $menu, 'HTML', false, false, true);
    setPage($userID, 'Articolo_' . $ID[1]);
}

//abilita disabilita anteprima link
if ($ID[0] == 'ModificaAnteprimaArticolo' and $userID == $isadminbot and $chatID > 0){

    $RowArticoloDB = $ID[3];
    $preview = $ID[1]; // Si o No
    $MSGID = $ID[2];

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$RowArticoloDB]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    //========== Informazioni Articolo
    $Date = $Associa['Date'];
    $Button = json_decode($Associa['Name_Article'], true); //decodifico il json
    $Text_Article = json_decode($Associa['Text_Article'], true); //decodifico il json
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];
    $Hide_Article = $Associa['Hide'];
    $Visual = $Associa['Visual'];
    //========== Informazioni Articolo

    if ($preview == 'Si'){
        //Diventare no
        $nwpreview = 'No';
        $pre = false;

        $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Disable_Link_Preview` = :preview WHERE `ID` = ' . $RowArticoloDB);
        $sth->bindParam(':preview', $pre, PDO::PARAM_STR, 7);
        $sth->execute();
    }
    if ($preview == 'No'){
        //Diventare no
        $nwpreview = 'Si';
        $pre = true;

        $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Disable_Link_Preview` = :preview WHERE `ID` = ' . $RowArticoloDB);
        $sth->bindParam(':preview', $pre, PDO::PARAM_STR, 7);
        $sth->execute();
    }

    //tasti di personalizzazione
    $menu[] = array(
        array(
            'text' => '🎈 Bottone',
            'callback_data' => 'ModificaBottone_' . $RowArticoloDB
        ),
        array(
            'text' => 'Testo ✏️',
            'callback_data' => 'ModificaTesto_' . $RowArticoloDB
        )
    );
    $menu[] = array(
        array(
            'text' => 'Nascondi Anteprima Link: ' . $nwpreview, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'ModificaAnteprimaArticolo_' . $nwpreview . '_' . $MSGID . '_' . $RowArticoloDB
        )
    );

    //Per disabilitare/abilitare la visaulizzazione delle notiza in bacheca per gli utenti
    if ($Hide_Article == 1) $Hide = 'Si'; else $Hide = 'No';
    $menu[] = array(
        array(
            'text' => '👁‍🗨 Oscura Articolo: ' . $Hide, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'OscuraArticolo_'. $Hide . '_' . $RowArticoloDB . '_' . $MSGID
        )
    );
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => 'BoardArticoliCreati'
        )
    );
    $txt = "📄 <b>Articoli Creati</b> 📄\n\n<i>Ecco l' anteprima dell' articolo e le relative informazioni.</i>\n\n<b>Bottone</b>: $Button\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Visualizzazioni</b>: $Visual";
    edit_message_preview_article($MSGID, false, false, $MSGID, $Text_Article, false, $Formatting, $pre); //dovrebbe modificare il mex de'utente
    cb_reply($cbid, 'Modificato', false, $cbmid, $txt, $menu, 'HTML');
}

//Oscura articolo
if ($ID[0] == 'OscuraArticolo' and $userID == $isadminbot and $chatID > 0){

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[2]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    //========== Informazioni Articolo
    $Date = $Associa['Date'];
    $Button = json_decode($Associa['Name_Article'], true); //decodifico il json
    $Text_Article = json_decode($Associa['Text_Article'], true); //decodifico il json
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];
    $Hide_Article = $Associa['Hide'];
    $Visual = $Associa['Visual'];

    if ($ID[1] == 'Si'){
        //Diventare no
        $oscura = 'No';
        $o = false;

        $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Hide` = :hide WHERE `ID` = ' . $ID[2]);
        $sth->bindParam(':hide', $o, PDO::PARAM_STR, 7);
        $sth->execute();
    }
    if ($ID[1] == 'No'){
        //Diventare no
        $oscura = 'Si';
        $o = true;

        $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Hide` = :hide WHERE `ID` = ' . $ID[2]);
        $sth->bindParam(':hide', $o, PDO::PARAM_STR, 7);
        $sth->execute();
    }

    //tasti di personalizzazione
    $menu[] = array(
        array(
            'text' => '🎈 Bottone',
            'callback_data' => 'ModificaBottone_' . $ID[2]
        ),
        array(
            'text' => 'Testo ✏️',
            'callback_data' => 'ModificaTesto_' . $ID[2]
        )
    );

    //Per disabilitare/abilitare l'anteprima dei link
    if ($Disable_Link_Preview == 1) {$preview = 'Si';} elseif ($Disable_Link_Preview == 0) {$preview = 'No';}
    $menu[] = array(
        array(
            'text' => 'Nascondi Anteprima Link: ' . $preview, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'ModificaAnteprimaArticolo_' . $preview . '_' . $ID[3] . '_' . $ID[2] //ID 3 è l'id del messaggio da modificare
        )
    );

    $menu[] = array(
        array(
            'text' => '👁‍🗨 Oscura Articolo: ' . $oscura, //Servono solo di visualizzazione non sono funzionali, perchè si modificano dal cb sopra
            'callback_data' => 'OscuraArticolo_'. $oscura . '_' . $ID[2] . '_' . $ID[3]
        )
    );
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => 'BoardArticoliCreati'
        )
    );

    $txt = "📄 <b>Articoli Creati</b> 📄\n\n<i>Ecco l' anteprima dell' articolo e le relative informazioni.</i>\n\n<b>Bottone</b>: $Button\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Visualizzazioni</b>: $Visual";
    cb_reply($cbid, 'Modificato', false, $cbmid, $txt, $menu, 'HTML');
    setPage($userID, 'Articolo_' . $ID[1]);
}

//Modifica Nome Bottone
if($ID[0] == "ModificaBottone" and $userID == $isadminbot and $chatID > 0) {

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => $PluginFileName
        )
    );
    $txt = "🎈 <b>Modifica Nome Bottone</b> 🎈\n\nInvia il <b>nuovo nome</b> del bottone oppure premi indietro per annullare la modifica.";
    cb_reply($cbid, 'Modifica Bottone', false, $cbmid, $txt, $menu, 'HTML');
    setPage($userID, 'ModificaBottone_' . $ID[1]);
}

if ($PageScomposta[0] == 'ModificaBottone' and $msg and $userID == $isadminbot and $chatID > 0){

    if(!in_array($msg, $MessaggiEsclusiBoard)){
        $menu[] = array(
            array(
                'text' => $msg,
                'callback_data' => 'EsempioNomeBottone'
            )
        );
        $menu[] = array(
            array(
                'text' => '🔙 Indietro',
                'callback_data' => 'VisualizzaArticolo_' . $PageScomposta[1]
            )
        );
        $encode = json_encode($msg, true); //va encodato il messaggio per salvarlo nel DB
        $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Name_Article` = :namearitcle WHERE `ID` = ' . $PageScomposta[1]);
        $sth->bindParam(':namearitcle', $encode, PDO::PARAM_STR, 7);
        $sth->execute();
        $updatedate = $db->query('UPDATE ' . $boardName . ' SET  `Date` = CURRENT_TIMESTAMP WHERE `ID` = ' . $PageScomposta[1]);

        $txt = "🎈 <b>Modifica Nome Bottone</b> 🎈\n\nNome del bottone <b>modificato!</b> Ecco una piccola anteprima di come comparirà.";
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
        setPage($userID, 'BottoneModificato_' . $ID[1]);
    }
}
if ($cbdata == 'EsempioNomeBottone' and $userID == $isadminbot and $chatID > 0){
    cb_reply($cbid, 'Questo sarà il nuovo nome del bottone', true);
}

//Modifica Testo
if($ID[0] == "ModificaTesto" and $userID == $isadminbot and $chatID > 0) {

    unlink($FileTemp);
    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    //Informazioni Articolo
    $Text_Article = json_decode($Associa['Text_Article'], true); //decodifico il json
    $Date = $Associa['Date'];
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];
    if ($Disable_Link_Preview == '1') $preview = 'Si'; else $preview = 'No';

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => 'VisualizzaArticolo_' . $ID[1]
        )
    );

    //Modifica messaggio con quello  dell' utente senza formattazione
    edit_message_preview_article($cbmid, 'Modifica Testo Articolo', false, $cbmid, $Text_Article, false, 'nothing', $Disable_Link_Preview);

    $txt = "✏️ <b>Modifica Testo Articolo</b> ✏️\n\nEcco il <b>vecchio testo</b> dell' articolo <b>senza formattazione</b> e le impostazioni:\n\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Disabilita Anteprima Link</b>: $preview\n\nInvia il <b>nuovo testo dell' articolo</b> premi indietro per annullare la modifica.";
    sm($chatID, $txt, $menu, 'HTML', false, false, true);
    setPage($userID, 'ModificaTesto_' . $ID[1]);
}

//Back senza rimandare il messaggio senza formattazione
if($ID[0] == "BackModificaTesto" and $userID == $isadminbot and $chatID > 0) {

    unlink($FileTemp);
    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    $Date = $Associa['Date'];
    $Formatting   = $Associa['Formatting'];

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => 'VisualizzaArticolo_' . $ID[1]
        )
    );

    $txt = "✏️ <b>Modifica Testo Articolo</b> ✏️\n\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Disabilita Anteprima Link</b>: $preview\n\nInvia di nuovo il <b>nuovo testo dell' articolo</b> premi indietro per annullare la modifica.";
    cb_reply($cbid, 'Modifica Bottone', false, $cbmid, $txt, $menu, 'HTML');
    setPage($userID, 'ModificaTesto_' . $ID[1]);
}

//A messaggio inviato per il nuov testo
if ($PageScomposta[0] == 'ModificaTesto' and $msg and $userID == $isadminbot and $chatID > 0){

    if(!in_array($msg, $MessaggiEsclusiBoard)){

        $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
        $Seleziona->execute([$PageScomposta[1]]);
        $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

        $Formatting   = $Associa['Formatting'];
        $Disable_Link_Preview = $Associa['Disable_Link_Preview'];

        if (send_message_preview_article($chatID, $msg, false, $Formatting, $Disable_Link_Preview, false, false, true)){
            //Crea file per memorizzare temporeaneamete il messaggio
            $myfile = fopen($FileTemp, "w") or die("Unable to open file!");
            $encode = json_encode($msg, true);
            fwrite($myfile, $encode);
            fclose($myfile);
            //--------------
            $Date = $Associa['Date'];
            if ($Disable_Link_Preview == '1') $preview = 'Si'; else $preview = 'No';

            $menu[] = array(
                array(
                    'text' => 'Conferma ✅',
                    'callback_data' => 'ConfermaModificaTesto_' . $PageScomposta[1]
                )
            );
            $menu[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'BackModificaTesto_' . $PageScomposta[1]
                )
            );

            $txt = "✏️ <b>Modifica Testo Articolo</b> ✏️\n\nEcco come comparirà l' articolo dopo le modifiche.\n\n<b>Data Ultima Modifica</b>: $Date\n<b>Formattazione</b>: <code>$Formatting</code>\n<b>Disabilita Anteprima Link</b>: $preview\n\nPremi <b>Conferma</b> per <b>applicare le modifiche</b>, oppure premi indietro se hai sbagliato o vuoi annullare l'operazione.";
            sm($chatID, $txt, $menu, 'HTML', false, false, true);
            setPage($userID, 'ConfermaModificaTesto_' . $PageScomposta[1]);
        } else {
            $erroback[] = array(
                array(
                    'text' => '🔙 Indietro',
                    'callback_data' => 'VisualizzaArticolo_' . $PageScomposta[1]
                )
            );
            $txterror = "✏️ <b>Modifica Testo Articolo</b> ✏️\n\n<i>Formattazione del testo non corretta, probabilmente hai sbagliato qualcosa nella sintassi.</i>\n\n<b>Reinvia</b> il testo formattato in modo corretto.";
            sm($chatID, $txterror, $erroback, 'HTML', false, false, true);
        }
    }
}

if($ID[0] == "ConfermaModificaTesto" and $userID == $isadminbot and $chatID > 0) {

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$PageScomposta[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);
    $TestoArticolo = file_get_contents($FileTemp); //salvo uesto perchè è già encodato

    $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Text_Article` = :text_article WHERE `ID` = ' . $PageScomposta[1]);
    $sth->bindParam(':text_article', $TestoArticolo, PDO::PARAM_STR, 7);
    $sth->execute();
    $updatedate = $db->query('UPDATE ' . $boardName . ' SET  `Date` = CURRENT_TIMESTAMP WHERE `ID` = ' . $PageScomposta[1]);

    unlink($FileTemp);

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => 'VisualizzaArticolo_' . $PageScomposta[1]
        )
    );

    $txt = "✏️ <b>Modifica Testo Articolo</b> ✏️\n\nModifiche del testo <b>apportate correttamente</b>.";
    cb_reply($cbid, 'Testo Modificato', false, $cbmid, $txt, $menu, 'HTML');
    setPage($userID, 'TestoModificato_' . $PageScomposta[1]);
}


/*------------------------------
Elimina Articolo
------------------------------*/
if(($cbdata == "BoardEliminaArticolo" or strpos($msg, "/eliminaarticoli")===0) and $userID == $isadminbot and $chatID > 0) {

    //Creazione Pulsanti
    $robe = array();
	$valori = array();
	$AddPulsBot = $db->query('SELECT * FROM `' . $boardName . '` ORDER BY `ID` DESC');
	if(isset($AddPulsBot) && $AddPulsBot) {
		$i = 1;
		while($Associa = $AddPulsBot->fetch(PDO::FETCH_ASSOC)) {
            $ID_Article = $Associa['ID'];
			$Name_Article = $Associa['Name_Article'];
            $AmministratoreBOT = $Associa['Chat_ID'];
			$valori[] = $ID_Article;
			$robe[$i] = $Name_Article;
			$i++;
		}

		$n = 1;
		$k = 0;
		$i = 1;
		$limite_riga = 1;
		foreach ($valori as $ID_art) {
			if($n > $limite_riga) {
				$n = 1;
				$k++;
			};
			$Name_Article = json_decode($robe[$i], true); //viene decodificato il json salvato nel DB
			$menu[$k][]=
				array(
					'text'=> $Name_Article,
					'callback_data' => 'EliminaArticolo_' . $ID_art
				);
			$n++;
			$i++;
		}
    }
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
            'callback_data' => $PluginFileName
        )
    );

    $txt = "➖ <b>Elimina Articolo</b> ➖\n\n<i>Da qui puoi eliminare i tuoi articoli dalla bacheca.</i>\n\nSeleziona l' articolo che vuoi <b>eliminare</b>.";
    if($cbdata){
        cb_reply($cbid, 'Elimina Articolo', false, $cbmid, $txt, $menu, 'HTML');
    } else{
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
    }
    setPage($userID, 'EliminaArticolo');
}

if($ID[0] == "EliminaArticolo" and $userID == $isadminbot and $chatID > 0) {

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    $Text_Article = json_decode($Associa['Text_Article'], true);
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];

    $menu[] = array(
        array(
            'text' => 'Conferma ✅',
            'callback_data' => 'ConfermaEliminaArticolo_' . $ID[1]
        )
    );
    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => 'BoardEliminaArticolo'
        )
    );

    //Modifica messaggio con quello  dell' utente senza formattazione
    edit_message_preview_article($cbmid, 'Elimina Articolo', false, $cbmid, $Text_Article, false, $Formatting, $Disable_Link_Preview);

    $txt = "➖ <b>Elimina Articolo</b> ➖\n\nSei sicuro di voler eliminare questo articolo?";
    sm($chatID, $txt, $menu, 'HTML', false, false, true);
    setPage($userID, 'ConfermaEliminaArticolo_' . $ID[1]);
}

if($ID[0] == "ConfermaEliminaArticolo" and $userID == $isadminbot and $chatID > 0) {

    $sth = $db->prepare('DELETE FROM `' . $boardName . '` WHERE `ID` = ' . $ID[1]);
	$sth->execute();

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => $PluginFileName
        )
    );

    $txt = "➖ <b>Elimina Articolo</b> ➖\n\nArticolo <b>cancellato</b> dalla bacheca correttamente.";
    cb_reply($cbid, 'Articolo Eliminato', false, $cbmid, $txt, $menu, 'HTML');
    setPage($userID, 'ArticoloEliminato_' . $ID[1]);
}


// ========================== [ Visualizza Bacheca Per gli Utenti Normali ] ==========================

if (($cbdata == $cb_apri_bacheca or strpos($msg, "/bacheca")=== 0) or strpos($cbdata, 'pagina')===0) {

    if ($cbdata == $cb_apri_bacheca or strpos($msg, "/bacheca")=== 0){$vecchia_callback = 'pagina 0';} else {$vecchia_callback = $update['callback_query']['data'];}
    $menu = CreaMenu_Scorrevole($vecchia_callback, 5);

    $other = true;
    if ($other == true){
        #insert here other buttons
        $menu[] = array(
            array(
                'text' => '🔙 Indietro',
                'callback_data' => 'start'
            )
        );
    }
    $select = $db->query('SELECT * FROM `' . $boardName . '` ORDER BY `ID` DESC LIMIT 1');
    $ass = $select->fetch(PDO::FETCH_ASSOC);
    if ($LastArticlePreview = remove_formatting(json_decode($ass['Text_Article'], true))) {$LastArticlePreview = substr($LastArticlePreview, 0, 100);}else {$LastArticlePreview = 'Error Preview!';}
    if($ass['Hide'] == true) {$LastArticlePreview = 'Error Preview!';}

    $txt = "📋 <b>Board $userbot</b> 📋\n\nBenvenuto $nome nella <b>bacheca</b>, qui troverai le <b>ultime notizie</b>, comunicazioni, ecc... Per restare sempre aggiornato controlla la bacheca <b>periodicamente</b>.\n\n<b>Ultimo Articolo</b>: <i>$LastArticlePreview</i>";
    if($cbdata){
        cb_reply($cbid, 'Bacheca', false, $cbmid, $txt, $menu, 'HTML');
    } else{
        sm($chatID, $txt, $menu, 'HTML', false, false, true);
    }
    setPage($userID, 'VisualizzaArticoloUTENTE');
}

//Visualizza articolo

if($ID[0] == "VisualizzaArticoloUTENTE") {

    $Seleziona = $db->prepare('SELECT * FROM `' . $boardName . '` WHERE `ID` = ?');
    $Seleziona->execute([$ID[1]]);
    $Associa   = $Seleziona->fetch(PDO::FETCH_ASSOC);

    $Name_Article = json_decode($Associa['Name_Article'], true);
    $Text_Article = json_decode($Associa['Text_Article'], true);
    $Formatting   = $Associa['Formatting'];
    $Disable_Link_Preview = $Associa['Disable_Link_Preview'];
    $Visual = $Associa['Visual'];
    $increment_Visual = $Visual+1;

    $sth = $db->prepare('UPDATE ' . $boardName . ' SET  `Visual` = :visual WHERE `ID` = ' . $ID[1]);
    $sth->bindParam(':visual', $increment_Visual, PDO::PARAM_STR, 7);
    $sth->execute();

    $menu[] = array(
        array(
            'text' => '🔙 Indietro',
                'callback_data' => $cb_apri_bacheca
        )
    );

    edit_message_preview_article($cbid, $Name_Article, false, $cbmid, $Text_Article, $menu, $Formatting, $Disable_Link_Preview); //dovrebbe modificare il mex de'utente
    setPage($userID, 'VisualizzaArticoloUTENTE_' . $ID[1]);
}
